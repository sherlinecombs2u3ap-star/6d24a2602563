// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("address sanitizer"); }
int main(){
  announce();
  return lionss_run_workload("address-sanitizer");
}
