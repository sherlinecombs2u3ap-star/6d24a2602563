// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("concurrency tests\n", stdout);
  return lionss_run_workload("concurrency-tests");
}
