// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("ios simulator"); }
int main(){
  announce();
  return lionss_run_workload("ios-simulator");
}
