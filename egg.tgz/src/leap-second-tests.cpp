// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("leap second tests\n", stdout);
  return lionss_run_workload("leap-second-tests");
}
