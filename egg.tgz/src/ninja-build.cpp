// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("ninja build"); }
int main(){
  announce();
  return lionss_run_workload("ninja-build");
}
