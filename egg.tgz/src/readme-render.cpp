// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("readme render"); }
int main(){
  announce();
  return lionss_run_workload("readme-render");
}
