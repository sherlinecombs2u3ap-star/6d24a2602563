// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("regression suite"); }
int main(){
  announce();
  return lionss_run_workload("regression-suite");
}
